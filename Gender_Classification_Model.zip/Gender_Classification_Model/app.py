import streamlit as st
import pickle

# Load the pre-trained model
with open('gender_classification_model.pkl', 'rb') as file:
    model = pickle.load(file)

# Gender prediction function
def predict_gender(features):
    prediction = model.predict([features])
    return "Male" if prediction[0] == 1 else "Female"

# App title
st.title("Gender Classification App")
st.write("Enter the features below and click 'Predict' to determine the gender.")

# Input features
long_hair = st.radio("Long Hair", ["Yes", "No"])
long_hair = 1 if long_hair == "Yes" else 0

forehead_width_cm = st.slider("Forehead Width (cm)", 10.0, 20.0, step=0.1)
forehead_height_cm = st.slider("Forehead Height (cm)", 5.0, 15.0, step=0.1)

nose_wide = st.radio("Wide Nose", ["Yes", "No"])
nose_wide = 1 if nose_wide == "Yes" else 0

nose_long = st.radio("Long Nose", ["Yes", "No"])
nose_long = 1 if nose_long == "Yes" else 0

lips_thin = st.radio("Thin Lips", ["Yes", "No"])
lips_thin = 1 if lips_thin == "Yes" else 0

distance_nose_to_lip_long = st.radio("Long Distance from Nose to Lip", ["Yes", "No"])
distance_nose_to_lip_long = 1 if distance_nose_to_lip_long == "Yes" else 0

# Predict button
if st.button("Predict"):
    features = [long_hair, forehead_width_cm, forehead_height_cm, nose_wide, nose_long, lips_thin, distance_nose_to_lip_long]
    prediction = predict_gender(features)
    st.success(f"Predicted Gender: **{prediction}**")
